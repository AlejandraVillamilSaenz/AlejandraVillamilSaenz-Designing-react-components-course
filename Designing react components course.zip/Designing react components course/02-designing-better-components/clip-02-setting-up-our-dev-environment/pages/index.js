const IndexPage = () => {
  return <div>Hello From Pluralsight!</div>;
};
export default IndexPage;
import Speakers from "../src/components/Speakers";
const IndexPage = () => {
  return <Speakers />;
};

export default IndexPage;

# overview

## 91-final

startout with loading (isloading, hasErrored and delay)

convert to loadingStatus instead and put status in constants global (research if this list he best way to do it)

add placeholder, explain place holder and pass this thru all layers if wanted

add theme with dropdown to speakerslist adding theme and settheme states

introduce {children} and see if there are other things like {children} 
  (I don't think there are other magic things coming in)

talk about moving theme to toolbar, state needs to move up a level, talk about toggleTheme is in
  toolbar which calls up a level to our speakers component (need to think this thru for 
  explaining, I'm confused with layout/speakers relationship and parent/child, etc.)

Add eventyear, seteventyear

Toggling eventYear, constants array

Add filtering speakers and sessions by event year 

Add favorite processing

THIS COULD BE END OF M3 AND POSSIBLY MOVE REDUCER CONVERSION TO M4 WITH OPTIMIZATION STUFF


OTHER THINGS: EVENTYEAR TOGGLING, FILTERING SESSIONS, SPEAKERS WHO HAVE SESSIONS.
  EVENTUALLY ADD FAVORITE STUFF

NEED TO THEN DO REDUCERS

THEN CHECK TO MAKE SURE ALLW ORKS WITH XSTATE


## 93-final

Reducers?

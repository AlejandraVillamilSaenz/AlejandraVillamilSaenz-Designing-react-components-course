import App from "../src/components/App";

const IndexPage = () => {
  return <App />;
};

export default IndexPage;
